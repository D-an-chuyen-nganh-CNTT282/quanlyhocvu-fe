export const environment = {
    production: false,
    apiBaseUrl: 'http://localhost:5055/api',        
};