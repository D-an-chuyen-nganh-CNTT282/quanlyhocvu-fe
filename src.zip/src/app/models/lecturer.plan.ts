export interface LecturePlan {
    id: string;
    planContent: string;
    startDate: Date;
    endDate: Date;
    note: string;
}