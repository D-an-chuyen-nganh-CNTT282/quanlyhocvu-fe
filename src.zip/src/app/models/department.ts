export interface Department {
    id: string;
    departmentName: string;
}