export interface BusinessCollaboration {
    id: string;
    businessId: string;
    projectName: Date;
    projectStatuss: string;
    result: string;
}