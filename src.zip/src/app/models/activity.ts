export interface Activity {
    id: string;
    name: string;
    eventDate: Date;
    location: string;
    eventTypes: string;
    description: string;
}