export interface StatisticsCount {
    Students: number;
    Alumni: number;
    Businesses: number;
    Lecturers: number;
}