export interface LecturerActivities {
    id: string;
    lecturerId: string;
    activitiesId: Date;
}