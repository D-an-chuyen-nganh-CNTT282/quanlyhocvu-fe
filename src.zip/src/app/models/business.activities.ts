export interface BusinessActivities {
    id: string;
    businessId: string;
    activitiesId: string;
}