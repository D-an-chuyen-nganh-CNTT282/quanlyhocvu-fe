export interface AlumniActivities {
    id: string;
    alumniId: string;
    activitiesId: string;
}