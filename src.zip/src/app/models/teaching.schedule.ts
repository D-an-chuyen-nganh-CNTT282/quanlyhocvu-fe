export interface TeachingSchedule {
    id: string;
    lecturerId: string;
    startDate: Date;
    endDate: Date;
    subject: string;
    classPeriod: string;
}