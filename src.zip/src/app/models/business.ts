export interface Business {
    id: string;
    lecturerId: string;
    businessName: Date;
    businessAddress: string;
    businessPhone: string;
    businessEmail: string;
}