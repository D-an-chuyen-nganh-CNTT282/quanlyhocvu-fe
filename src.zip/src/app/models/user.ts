export interface User {
    id: string;
    name: string;
    email: string;
    phoneNumber: string;
    roleName: string;
}