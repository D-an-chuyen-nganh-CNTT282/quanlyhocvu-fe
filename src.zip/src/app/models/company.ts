export interface Company {
    id: string;
    userId: string;
    companyName: string;
    companyAddress: Date;
    companyPhone: string;
    companyEmail: string;
}