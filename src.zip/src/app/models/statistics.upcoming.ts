export interface StatisticsUpcoming {
    id: string;
    name: string;
    eventDate: Date,
    location: string;
    eventTypes: string;
    description: string;
}