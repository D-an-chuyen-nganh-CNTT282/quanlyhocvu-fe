export interface OutComingDocument {
    OutgoingDocumentTitle: string;
    OutgoingDocumentContent: string
    SendDate: Date;
    DepartmentId: string;
    RecipientEmail: string;
    UserId: string;
    OutgoingDocumentProcessingStatuss: string;
    DueDate: Date;
}