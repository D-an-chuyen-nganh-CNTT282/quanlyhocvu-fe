export interface Lecture {
    id: string;
    lecturerName: string;
    dayOfBirth: Date
    lecturerGender: string;
    lecturerEmail: string;
    lecturerPhone: string;
    lecturerAddress: string;
    expertise: string;
}