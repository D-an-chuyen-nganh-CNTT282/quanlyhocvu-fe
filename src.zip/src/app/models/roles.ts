export interface Role {
    roleId: string;
    roleName: string;
}