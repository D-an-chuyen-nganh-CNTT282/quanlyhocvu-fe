export interface ExtracurricularActivities {
    id: string;
    studentId: string;
    activitiesId: string;
}